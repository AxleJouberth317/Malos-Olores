/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comments;

/**
 *
 * @author Jouberth
 */
public class NewClass {
    int num1;
    int num2;;
    
    /*Este metodo compara dos numeros y retorna un entero, si el primero es mayor
    retorna 1, si el segundo retorna 2 y si son iguales retorna 3*/
    public int operation(int n1,int n2){
        int result;
        if(n1>n2)
            result =1;
        if(n1<n2)
            result =2;
        if(n1==n2);
            result =3;
       
        return result;
    }
}
