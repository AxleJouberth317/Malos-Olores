/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataClumps;

/**
 *
 * @author Jouberth
 */
public class Pago {
    public void SubmitCreditCardOrder(String Nombre, String Apellido,
        String codigoZIP, String direccion, String ciudad, 
        String provincia, String pais, String numeroTelefono, String numeroTarjeta, 
        int mesExpiracion, int añoExpiracion, double montoTotal){
    
        // … realizar pago
    }


}
