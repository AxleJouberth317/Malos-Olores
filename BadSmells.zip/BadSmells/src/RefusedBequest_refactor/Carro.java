/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RefusedBequest_refactor;

/**
 *
 * @author Jouberth
 */
public class Carro extends Vehiculo{ //Usando Push Down Method
    void Drive() { } 
}
