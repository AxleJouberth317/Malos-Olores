/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchStatement_refactor;

import java.util.List;

/**
 *
 * @author Jouberth
 */
public class MergeSort extends Sorter{
    public List<String> GetSortedData(String searchType, List<String> data){
        List<String> sortedData = null;
        //Peform Merge Sort and assign to data.  
            sortedData = data;
        return sortedData;
    }
}
