/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrimitiveObsession;

/**
 *
 * @author Jouberth
 */
public class Cliente{
    public String cuentaCorriente;

    public void setCuentaCorriente(String cuenta) {
        if(cuenta==null);
        this.cuentaCorriente = cuenta;
    }

    public String getCuentaCorriente() {
        return cuentaCorriente;
    }
    
}
