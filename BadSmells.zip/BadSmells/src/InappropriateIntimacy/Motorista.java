/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InappropriateIntimacy;

/**
 *
 * @author Jouberth
 */
public class Motorista {
    public Licencia licencia;
    private String nombre;
    private String apellido;

    public Motorista(Licencia licencia, String nombre, String apellido) {
        this.licencia = licencia;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
    
    public void getFactorRiesgo(){
        if(licencia.getPuntos() > 3)
            System.out.println("Peligro Alto");
        if(licencia.getPuntos() > 0)
            System.out.println("Peligro Moderado");
        else System.out.println("Peligro Bajo");
    }
}
