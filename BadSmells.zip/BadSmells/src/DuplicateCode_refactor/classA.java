/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DuplicateCode_refactor;

/**
 *
 * @author Jouberth
 */
public class classA {  //Usando Extract Method
    int base;
    int altura;
    int lado;
    
    int calcularAreaRectangulo(){
        return calcularAreaFiguras(base,altura);
    }
    
    int calcularAreaCuadrado(){
        return calcularAreaFiguras(lado,lado);
    }
    
    int calcularAreaFiguras(int lado1,int lado2){
        return lado1*lado2;
    }
    
}


