/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LongMethod;

import java.util.Iterator;

/**
 *
 * @author Jouberth
 */
public class ClassIterator {
    String name;
    
    private String toStringHelper(StringBuffer result){
        result.append("<");
        result.append(name);
        result.append(attributes.toString());
        result.append(">");
        if(!value.equals(""))
            result.append(value);
        Iterator it = children().iterator();
        while (it.hasNext()){
            TagNode node = (TagNode)it.next();
            node.toStringHelper(result);
        }
        result.append("</");
        result.append(name);
        result.append(">");
        return result.toString();
    }
}

