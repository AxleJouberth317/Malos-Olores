/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataClass_refactor;

import java.util.List;

/**
 *
 * @author Jouberth
 */
public class Carro {  //Usando Encapsulated Field y Move Method
    private String matricula;
    private String marca;
    private List<String> Partes;
  
    void showMarca(){
        System.out.println(marca);
    }
    
    void showMatricula(){
        System.out.println(matricula);
    }


    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public List<String> getPartes() {
        return Partes;
    }

    public void setPartes(List<String> Partes) {
        this.Partes = Partes;
    }
}

