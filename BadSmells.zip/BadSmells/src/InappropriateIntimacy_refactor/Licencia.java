/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InappropriateIntimacy_refactor;

/**
 *
 * @author Jouberth
 */
public class Licencia { //Usando Move Method
    Motorista motorista;
    private int puntos = 0;

    public int getPuntos() {
        return puntos;
    }

    public void setMotorista(Motorista motorista) {
        this.motorista = motorista;
    }
    
    public void agregarPuntos(int puntos){
        this.puntos += puntos;
    }
    
}
