/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataClumps_refactor;

/**
 *
 * @author Jouberth
 */
public class TarjetaCredito {
    String numeroTarjeta; 
    int mesExpiracion; 
    int añoExpiracion;
}
