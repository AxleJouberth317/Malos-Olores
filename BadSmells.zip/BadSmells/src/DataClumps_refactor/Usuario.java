/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataClumps_refactor;

/**
 *
 * @author Jouberth
 */
public class Usuario {
    String Nombre; 
    String Apellido;
    String codigoZIP;
    String direccion;
    String ciudad;
    String provincia;
    String pais;
    String numeroTelefono;
}
