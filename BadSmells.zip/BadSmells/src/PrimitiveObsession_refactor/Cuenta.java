/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrimitiveObsession_refactor;

/**
 *
 * @author Jouberth
 */
public class Cuenta {
    String tipo;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if(tipo==null);
        this.tipo = tipo;
    }
}
