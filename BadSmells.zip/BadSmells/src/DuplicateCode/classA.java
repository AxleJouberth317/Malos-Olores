/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DuplicateCode;

/**
 *
 * @author Jouberth
 */
public class classA {
    int base;
    int altura;
    int lado;
    
    int calcularAreaRectangulo(int base,int altura){
        return base*altura;
    }
    
    int calcularAreaCuadrado(int lado1,int lado2){
        return lado1*lado2;
    }
   
}
