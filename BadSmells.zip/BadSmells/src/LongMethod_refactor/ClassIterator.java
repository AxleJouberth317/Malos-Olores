/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LongMethod_refactor;

import java.util.Iterator;

/**
 *
 * @author Jouberth
 */
public class ClassIterator { //Usando Extract Method
    String name;
    
    private String toStringHelper(StringBuffer result){
     writeOpenTagTo(result);
     writeValueTo(result);
     writeChildrenTo(result);
     writeEndTagTo(result);
     return result.toString();
    }
    
    private void writeOpenTagTo(StringBuffer result){
        result.append("<");
        result.append(name);
        result.append(attributes.toString());
        result.append(">");
    }
    
    private void writeValueTo(StringBuffer result){
        if(!value.equals(""))
            result.append(value);
    }
    
    private void writeChildrenTo(StringBuffer result){
        Iterator it = children().iterator();
        while (it.hasNext()){
            TagNode node = (TagNode)it.next();
            node.toStringHelper(result);
        }
    }
    
    private void writeEndTagTo(StringBuffer result){
        result.append("</");
        result.append(name);
        result.append(">");
    }
}
